// Altere este número para o WhatsApp oficial da loja
// Formato: somente números, com DDI e DDD. Exemplo: 5521999999999
export const STORE_WHATSAPP_NUMBER = '5521000000000'