import React from 'react'
import Carousel from '../components/Carousel'
import ProductGrid from '../components/ProductGrid'
import Cart from '../components/Cart'

function Home() {
  return (
    <div className="home-page">
      <Carousel />
      <div className="home-layout">
        <div className="home-left">
          <ProductGrid />
        </div>
        <div className="home-right">
          <Cart />
        </div>
      </div>
    </div>
  )
}

export default Home